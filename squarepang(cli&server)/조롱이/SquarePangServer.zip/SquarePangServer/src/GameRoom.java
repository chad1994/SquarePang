import java.util.List;

public class GameRoom{
	
	public GameRoom() {
		
	}
	
}