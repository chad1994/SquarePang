package com.example.jun.squarepang;

/**
 * Created by Jun on 2017-11-15.
 */

public class User_info {

    static String name =null;
    static String yourname = null;

}
