import java.util.List;

public class RoomManager {
	List<GameRoom> roomList;
	
}
